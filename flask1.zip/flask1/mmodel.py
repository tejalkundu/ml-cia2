import pandas as pd



dataset=pd.read_csv(r"C:\Users\Vaishnavi\Downloads\flask1\insurance.csv")
dataset.replace({'sex':{'male':0 , 'female':1}}, inplace = True)
dataset.replace({'smoker':{'no':0 , 'yes':1}}, inplace = True)
dataset.replace({'region':{'southeast':0 , 'southwest':1 , 'northeast':2, 'northwest':3}}, inplace = True)
dataset.head()


X=dataset.drop(columns='charges',axis=1)
Y=dataset['charges']


from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=0.33, random_state=42)
from sklearn.linear_model import LinearRegression
lr=LinearRegression()
lr.fit(X_train,y_train)
prediction=lr.predict(X_train)


import pickle

pickle.dump(lr,open("model1.pkl","wb"))



